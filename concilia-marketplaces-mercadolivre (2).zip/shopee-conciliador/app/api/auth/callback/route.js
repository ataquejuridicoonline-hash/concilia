import crypto from 'node:crypto';
import {db,checked} from '../../../../lib/db.js';
import {exchange} from '../../../../lib/shopee.js';
import {seal} from '../../../../lib/secret.js';
export async function GET(request){
 const url=new URL(request.url);const state=url.searchParams.get('state'),code=url.searchParams.get('code'),shopId=url.searchParams.get('shop_id');
 const home=new URL('/',process.env.APP_URL||url.origin);
 try{
 if(!state||!code||!shopId||!/^\d+$/.test(shopId))throw Error('Retorno OAuth incompleto');
 const state_hash=crypto.createHash('sha256').update(state).digest('hex');
 // Primeiro consome o estado, impedindo reuso; válido uma vez.
 const states=await checked(db().from('shopee_oauth_states').delete().eq('state_hash',state_hash).gt('expires_at',new Date().toISOString()).select('state_hash'));
 if(!states?.length)throw Error('Autorização expirada ou inválida');
 const t=await exchange(code,shopId);if(!t.access_token||!t.refresh_token)throw Error('Shopee não retornou tokens');
 await checked(db().from('shopee_connections').upsert({shop_id:Number(shopId),access_token_cipher:seal(t.access_token),refresh_token_cipher:seal(t.refresh_token),expires_at:new Date(Date.now()+(t.expire_in||14400)*1000).toISOString(),updated_at:new Date().toISOString()},{onConflict:'shop_id'}));
 home.searchParams.set('connected','1');
 }catch(e){home.searchParams.set('error',e.message.slice(0,90));}
 return Response.redirect(home,303);
}
