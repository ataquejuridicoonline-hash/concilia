import crypto from 'node:crypto';
import {admin,db,checked} from '../../../../lib/db.js';
import {authorizationUrl} from '../../../../lib/shopee.js';
export async function POST(request){try{
 if(!await admin(request))return Response.json({error:'Não autorizado'},{status:401});
 const state=crypto.randomBytes(24).toString('hex');const state_hash=crypto.createHash('sha256').update(state).digest('hex');
 await checked(db().from('shopee_oauth_states').insert({state_hash,expires_at:new Date(Date.now()+10*60000).toISOString()}));
 return Response.json({url:authorizationUrl(state)});
 }catch(e){return Response.json({error:e.message},{status:500})}}
