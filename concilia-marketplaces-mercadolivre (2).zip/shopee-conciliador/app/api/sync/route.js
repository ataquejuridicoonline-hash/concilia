import {admin,db,checked} from '../../../lib/db.js';
import {validConnection} from '../../../lib/connection.js';
import {orderPage,orderDetails,escrowDetail,normalize} from '../../../lib/shopee.js';
export const maxDuration=60;
export async function POST(request){
 let runId=null;try{
 if(!await admin(request))return Response.json({error:'Não autorizado'},{status:401});
 const c=await validConnection(); const now=Math.floor(Date.now()/1000); const from=now-7*86400;
 const run=await checked(db().from('shopee_sync_runs').insert({shop_id:c.shop_id}).select('id').single());runId=run.id;
 let cursor='',sns=[],pageCount=0;
 do{
  const page=await orderPage(c.shop_id,c.accessToken,from,now,cursor);
  sns.push(...(page.order_list||[]).map(o=>o.order_sn).filter(Boolean));
  cursor=page.more?page.next_cursor||'':'';pageCount++;
  if(page.more&&!cursor)throw Error('Paginação incompleta: cursor ausente');
 }while(cursor&&pageCount<20);
 if(cursor)throw Error('Limite de páginas atingido; sincronização incompleta');
 sns=[...new Set(sns)];let processed=0;
 for(let i=0;i<sns.length;i+=25){
  const chunk=sns.slice(i,i+25);const details=await orderDetails(c.shop_id,c.accessToken,chunk);
  for(const order of details.order_list||[]){
   let escrow=null;try{escrow=await escrowDetail(c.shop_id,c.accessToken,order.order_sn)}catch(e){/* não registrar como valor zero; ausência de detalhe é distinta de erro */}
   const record={...normalize(order,escrow),shop_id:c.shop_id};
   await checked(db().from('shopee_orders').upsert(record,{onConflict:'shop_id,order_sn'}));processed++;
  }
 }
 await checked(db().from('shopee_sync_runs').update({finished_at:new Date().toISOString(),status:'success',processed}).eq('id',runId));
 return Response.json({processed,note:'Valores contábeis consultados; liberação comprovada e transferência bancária ainda não verificadas.'});
 }catch(e){if(runId)await db().from('shopee_sync_runs').update({finished_at:new Date().toISOString(),status:'error',error_message:e.message}).eq('id',runId);return Response.json({error:e.message},{status:500})}
}
