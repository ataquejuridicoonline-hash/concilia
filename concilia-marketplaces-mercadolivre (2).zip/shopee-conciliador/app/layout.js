import './style.css';
export const metadata={title:'Concilia Shopee',description:'Auditoria financeira das vendas Shopee'};
export default function RootLayout({children}){return <html lang="pt-BR"><body>{children}</body></html>}
