-- Execute uma única vez no SQL Editor do Supabase.
-- Sem políticas públicas: somente o servidor com chave service_role, após validar ADMIN_USER_ID.
create extension if not exists pgcrypto;
create table if not exists public.shopee_connections (
  id uuid primary key default gen_random_uuid(),
  shop_id bigint not null unique,
  access_token_cipher text not null,
  refresh_token_cipher text not null,
  expires_at timestamptz not null,
  connected_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.shopee_orders (
  id uuid primary key default gen_random_uuid(),
  shop_id bigint not null references public.shopee_connections(shop_id) on delete cascade,
  order_sn text not null,
  order_status text,
  order_created_at timestamptz,
  gross_amount numeric(16,2),
  net_amount numeric(16,2),
  commission_fee numeric(16,2),
  service_fee numeric(16,2),
  transaction_fee numeric(16,2),
  release_evidence boolean not null default false,
  data_quality text not null default 'sem_detalhe',
  order_raw jsonb,
  escrow_raw jsonb,
  last_checked_at timestamptz not null default now(),
  unique(shop_id, order_sn)
);
create index if not exists idx_orders_status on public.shopee_orders(shop_id, order_status);
create index if not exists idx_orders_created on public.shopee_orders(shop_id, order_created_at desc);
create table if not exists public.shopee_sync_runs (
 id uuid primary key default gen_random_uuid(), shop_id bigint,
 started_at timestamptz not null default now(), finished_at timestamptz,
 status text not null default 'running', processed int not null default 0,
 error_message text
);
create table if not exists public.shopee_oauth_states (
  state_hash text primary key,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
alter table public.shopee_connections enable row level security;
alter table public.shopee_orders enable row level security;
alter table public.shopee_sync_runs enable row level security;
alter table public.shopee_oauth_states enable row level security;
revoke all on public.shopee_connections,public.shopee_orders,public.shopee_sync_runs,public.shopee_oauth_states from anon,authenticated;
-- Não criar políticas anon/authenticated: confidencialidade mantida no backend.
