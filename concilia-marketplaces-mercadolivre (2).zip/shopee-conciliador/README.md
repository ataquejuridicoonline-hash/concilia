# Concilia Shopee — MVP 0.1

**Estado:** projeto inicial executável, não conectado nem implantado. Esta versão consulta pedidos e detalhamento contábil por pedido. **Ainda não prova liberação definitiva ou transferência à conta bancária.** Não confundir `escrow_amount` com depósito recebido.

## Requisitos
- Node.js 20.9+; conta Vercel; projeto Supabase; conta desenvolvedor e app aprovados na Shopee Open Platform (solicitar acesso às APIs de Order e Payment).

## Instalação local
1. `npm install`
2. Copie `.env.example` para `.env.local` e preencha o Supabase.
3. Em Supabase > SQL Editor, execute `supabase/schema.sql`.
4. Em Supabase > Authentication > Users, crie um usuário administrador; configure `ADMIN_USER_ID` com o **UUID** desse usuário. Por segurança, desative signup público; o backend só aceita esse UUID.
5. `npm run dev` e acesse `http://localhost:3000`. Sem API Shopee, escolha **Ver demonstração**.
6. Ao obter credenciais Shopee, configure `SHOPEE_PARTNER_ID`, `SHOPEE_PARTNER_KEY`, `TOKEN_ENCRYPTION_KEY` (gerar usando `openssl rand -hex 32`) e `APP_URL` com a URL HTTPS real de produção.
7. No console de seu app Shopee, registre URL de retorno `https://SEU_DOMINIO/api/auth/callback` conforme a configuração do seu app e autorize a loja pelo botão **Conectar loja**. O redirect inclui `state` como query param; confirme no cadastro de app se a plataforma exige endereço exato.
8. Clique **Sincronizar 7 dias** para consultar pedidos atualizados no período de 7 dias, com busca de detalhes por pedido. É manual nesta primeira versão.

## Implantação na Vercel
1. Suba a pasta em repositório privado GitHub.
2. Vercel > Add New > Project > importe o repositório; framework Next.js.
3. Adicione variáveis de `.env.example` em Settings > Environment Variables; **não** use prefixo `NEXT_PUBLIC_` para chaves secretas.
4. Configure `APP_URL` com domínio de produção HTTPS, por exemplo `https://seu-projeto.vercel.app`.
5. Deploy; teste login, conexão Shopee, sync e dados. Nunca envie `.env.local` ao GitHub.

## Esquema e controles
- `shopee_connections`: credenciais OAuth criptografadas com AES-256-GCM no servidor.
- `shopee_orders`: pedido, situação, valores contábeis, respostas originais da API para auditoria.
- `shopee_sync_runs`: histórico de sincronização.
- `shopee_oauth_states`: nonce de autorização OAuth válido por 10 minutos, consumido uma vez.
- RLS habilitado sem políticas para cliente, acesso permitido apenas pelo servidor usando chave secreta e autenticação de administrador. Endpoints bloqueiam usuários que não correspondam a `ADMIN_USER_ID`.

## Limitações e próximos ajustes necessários antes de operação financeira
- Nesta primeira versão, `get_escrow_detail` fornece o valor contábil do pedido; **não classifica pedido como liberado**. Para liberação efetiva, integrar e validar `payment.get_escrow_list` e/ou `payment.get_income_detail` com respostas reais da loja. Somente depois preencher `release_evidence` a partir do status/data de liberação da fonte.
- Nunca contar pedido sem detalhe como valor líquido zero, pago ou diferença financeira.
- Sincronização de 7 dias usa `update_time`; pedidos antigos liberados tardiamente podem não aparecer. Próxima versão deve incluir paginação temporal por liberações e backfill histórico.
- A API possui limites e permissões por aplicativo: confira documentação de sua conta e teste em sandbox antes de produção. Lotes grandes podem exceder o tempo de função da Vercel; migrar para jobs incrementais e filas.
- Reexecução é idempotente por `(shop_id, order_sn)`. Reagendamentos/concorrência de refresh token devem usar bloqueio transacional antes de habilitar cron paralelo.
- O endpoint de detalhe pode retornar erros transitórios: aprimorar retry e registrar falhas individuais antes de usar como auditoria definitiva.
- O projeto **não valida** transferências bancárias, estornos posteriores ou ajuste líquido de repasses; isso virá em fase 2.

## Fontes
- https://open.shopee.com/documents?module=97&type=1
- https://supabase.com/docs/guides/auth/server-side/creating-a-client
- https://vercel.com/docs/deployments

## Teste
`npm test` executa testes de normalização; `npm run build` verifica compilação, quando as dependências estiverem instaladas.

## Integração Mercado Livre — etapa 1

1. Execute `supabase/mercadolivre.sql` no Supabase **do mesmo projeto** da aplicação. Não exclua as tabelas existentes.
2. Em Vercel → Environment Variables → Production configure `MELI_CLIENT_ID`, `MELI_CLIENT_SECRET` (Secret), `MELI_REDIRECT_URI`, `TOKEN_ENCRYPTION_KEY` (Secret), `APP_URL`, `ADMIN_USER_ID` e as chaves Supabase já utilizadas. `TOKEN_ENCRYPTION_KEY` é compartilhado com o Shopee e não deve ser trocado caso já existam tokens criptografados. Gere uma chave com `openssl rand -hex 32` caso ainda não exista.
3. Em Mercado Livre Developers, a Redirect URI deve corresponder **exatamente** a `MELI_REDIRECT_URI`.
4. Faça deploy, autentique no painel, use **Conectar Mercado Livre** e autorize com a conta principal do vendedor (não colaborador).
5. Clique **Sincronizar pedidos (7 dias)**. Inicialmente importa até 200 pedidos recentes por execução; não é histórico completo.
6. **Importante**: totais, tarifas do pedido e status de pagamento não comprovam liberação ou crédito bancário. A integração Mercado Pago e relatórios de liquidação são uma etapa futura.

**Segurança:** não cole tokens ou client secrets em chats; revogue qualquer segredo que tenha sido compartilhado. O endpoint de callback usa state de uso único, vencimento, PKCE S256 e tokens criptografados. As rotas administrativas exigem `ADMIN_USER_ID`.
